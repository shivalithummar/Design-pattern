/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author admin
 */
public class CookingStaff {
	
	public void cookLunch() {
		System.out.println("Lunch is in progress!!!");
	}

	public void cookDinner() {
		System.out.println("Dinner is in progress!!!");
	}

}
