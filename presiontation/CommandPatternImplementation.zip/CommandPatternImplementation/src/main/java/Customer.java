/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author admin
 */
public class Customer {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        CookingStaff cookingStaff = new CookingStaff();
		LunchOrder lunchOrder = new LunchOrder(cookingStaff);
		DinnerOrder dinnerOrder = new DinnerOrder(cookingStaff);

		Waiter waiter = new Waiter();
		waiter.placeOrder(lunchOrder);
		waiter.placeOrder(dinnerOrder);
		
    }
    
}
